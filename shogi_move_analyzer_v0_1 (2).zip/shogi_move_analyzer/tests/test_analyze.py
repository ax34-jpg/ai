import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from analyze import parse_info, exact_cp, metrics, load_game, analyze, search
ROOT = Path(__file__).resolve().parents[1]


def row(move, cp, depth=2, rank=1):
    return parse_info(f'info depth {depth} multipv {rank} score cp {cp} nodes 100 pv {move}')


class Tests(unittest.TestCase):
    def test_bounds(self):
        r = parse_info('info depth 2 score cp 30 lowerbound pv 7g7f')
        self.assertIsNone(exact_cp(r))
    def test_mate(self):
        r = parse_info('info depth 2 score mate -5 pv 7g7f')
        self.assertEqual(r['score']['value'], -5)
        self.assertIsNone(exact_cp(r))
        self.assertEqual(parse_info('info depth 2 score mate + pv 7g7f')['score']['value'], '+')
    def test_bad_info(self):
        for s in ('info string score cp 50 pv 7g7f', 'info depth ? score cp 1 pv 7g7f', 'info nodes 200'):
            self.assertIsNone(parse_info(s))
    def test_discovery(self):
        stages = [{'requested_nodes':10,'rows':[row('2g2f',30)]},
                  {'requested_nodes':100,'rows':[row('7g7f',200),row('2g2f',0,rank=2)]}]
        m = metrics(stages,'7g7f',None,150)
        self.assertEqual(m['stable_from_tested_node_budget'],100)
        self.assertIn('best_move_emerges_at_larger_budget',m['candidate_reasons'])
        self.assertEqual(m['best_minus_played_cp'],0)
    def test_negative_delta_preserved(self):
        m = metrics([{'requested_nodes':10,'rows':[row('7g7f',0)]}], '2g2f', {'rows':[row('2g2f',30)]},150)
        self.assertEqual(m['best_minus_played_cp'],-30)
    def test_unknown_is_not_stable(self):
        m = metrics([{'requested_nodes':10,'rows':[]},{'requested_nodes':100,'rows':[row('7g7f',0)]}], '7g7f',None,150)
        self.assertIsNone(m['stable_from_tested_node_budget'])
    def test_illegal_game(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad.json'
            p.write_text(json.dumps({'moves':['7g7e']}))
            with self.assertRaises(ValueError): load_game(p)
    def test_kif_encodings(self):
        text='手合割：平手\n先手：試験\n後手：確認\n手数----指手---------消費時間--\n1 ７六歩(77)\n2 ３四歩(33)\n3 投了\n'
        with tempfile.TemporaryDirectory() as td:
            for enc in ('utf-8-sig','cp932'):
                p=Path(td)/(enc+'.kif')
                p.write_text(text,encoding=enc)
                self.assertEqual(load_game(p)['moves'],['7g7f','3c3d'])
    def test_end_to_end(self):
        cfg={'command':[sys.executable,str(ROOT/'tests/fake_engine.py')], 'node_budgets':[100,1000], 'multipv':3}
        with tempfile.TemporaryDirectory() as td:
            r=analyze(ROOT/'sample_game.json',cfg,Path(td)/'result')
            self.assertEqual(r['status'],'complete')
            self.assertEqual(len(r['positions']),4)
            self.assertEqual([p['side'] for p in r['positions']],['black','white','black','white'])
            self.assertTrue((Path(td)/'result/summary.csv').exists())
            for p in r['positions']:
                for s in p['stages']:
                    self.assertEqual(s['effective_options']['PvInterval'],0)
                    self.assertEqual(s['complete_depth'],2)
                    self.assertEqual(len(s['rows']),3)
    def test_timeout(self):
        cfg={'command':[sys.executable,'-c','import time; time.sleep(10)'],'timeout_seconds':0.05}
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(TimeoutError):
                search(cfg,'position startpos',10,3,Path(td)/'timeout.log')

if __name__ == '__main__': unittest.main()
