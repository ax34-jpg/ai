import unittest
from analyze import summarize_events, parse_info, metrics

def row(rank,depth,move,score='cp 50'):
 return parse_info(f'info depth {depth} multipv {rank} score {score} nodes 100 pv {move}')

class Regression(unittest.TestCase):
 def test_mixed_depth_retained_not_compared(self):
  s=summarize_events([row(1,10,'2g2f'),row(2,10,'7g7f'),row(3,9,'6i7h')],3,'2g2f')
  self.assertEqual(len(s['rows']),3)
  self.assertFalse(s['comparison_ready'])
  s.update(bestmove='2g2f',requested_nodes=100)
  self.assertIsNone(metrics([s],'2g2f',None,150)['best_minus_played_cp'])
 def test_batches_not_combined(self):
  s=summarize_events([row(1,10,'2g2f'),row(2,10,'7g7f'),row(1,10,'7g7f'),row(3,10,'6i7h')],3,'7g7f')
  self.assertFalse(s['comparison_ready'])
 def test_previous_exact_snapshot_preserved(self):
  s=summarize_events([row(1,9,'2g2f'),row(2,9,'7g7f'),row(3,9,'6i7h'),row(1,10,'2g2f','cp 80 lowerbound'),row(2,10,'7g7f'),row(3,9,'6i7h')],3,'2g2f')
  self.assertTrue(s['comparison_ready'])
  self.assertEqual(s['comparison_depth'],9)
  self.assertEqual(s['latest_rows'][0]['score']['bound'],'lower')
 def test_duplicate_moves_rejected(self):
  s=summarize_events([row(1,9,'2g2f'),row(2,9,'2g2f'),row(3,9,'6i7h')],3,'2g2f')
  self.assertFalse(s['comparison_ready'])
 def test_final_bestmove_mismatch(self):
  s=summarize_events([row(1,9,'2g2f'),row(2,9,'7g7f')],2,'7g7f')
  self.assertFalse(s['comparison_ready'])
 def test_bounds_not_exact(self):
  s=summarize_events([row(1,9,'2g2f','cp 80 lowerbound'),row(2,9,'7g7f')],2,'2g2f')
  self.assertFalse(s['comparison_ready'])
 def test_missing_rank(self):
  s=summarize_events([row(1,9,'2g2f')],3,'2g2f')
  self.assertEqual(len(s['rows']),1)
  self.assertFalse(s['comparison_ready'])
 def test_bestmove_tracks_without_scores(self):
  s=[dict(rows=[],comparison_ready=False,bestmove=m,requested_nodes=n) for m,n in [('7g7f',10),('2g2f',100)]]
  self.assertEqual(metrics(s,'2g2f',None,150)['stable_from_tested_node_budget'],100)
