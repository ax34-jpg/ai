"""Protocol fixture only. Scores are synthetic, never chess/shogi analysis."""
import sys
import shogi
board = shogi.Board()
k = 3
for line in sys.stdin:
    t = line.strip()
    if t == 'usi':
        print('id name SYNTHETIC_TEST_ENGINE')
        print('option name PvInterval type spin default 300 min 0 max 100000')
        print('option name MultiPV type spin default 1 min 1 max 100')
        print('usiok', flush=True)
    elif t.startswith('setoption name MultiPV value '):
        k = int(t.split()[-1])
    elif t == 'isready':
        print('readyok', flush=True)
    elif t.startswith('position sfen '):
        parts = t[len('position sfen '):].split(' moves ')
        board = shogi.Board(parts[0])
        if len(parts)>1:
            for move in parts[1].split():
                board.push_usi(move)
    elif t.startswith('go '):
        moves = [m.usi() for m in board.legal_moves]
        if 'searchmoves' in t:
            moves = [t.split('searchmoves ')[1]]
        for depth in (1, 2):
            for rank, move in enumerate(moves[:k], 1):
                print(f'info depth {depth} multipv {rank} score cp {100-rank*20} nodes 100 time 1 pv {move}')
        print('bestmove ' + moves[0], flush=True)
    elif t == 'quit':
        break
