"""One-game USI analysis. Python 3.10+, python-shogi 1.1.1."""
import argparse
import csv
import hashlib
import json
import queue
import re
import subprocess
import threading
import time
from pathlib import Path
import shogi
import shogi.KIF


def parse_info(line):
    t = line.split()
    if not t or t[0] != 'info' or 'string' in t or 'pv' not in t or 'score' not in t:
        return None
    try:
        i = t.index('score')
        kind, value = t[i+1:i+3]
        if kind not in ('cp', 'mate'):
            return None
        score = {'kind': kind, 'value': int(value) if value not in ('+', '-') else value,
                 'bound': 'lower' if 'lowerbound' in t else 'upper' if 'upperbound' in t else None}
        r = {'score': score, 'pv': t[t.index('pv')+1:]}
        for key in ('depth', 'seldepth', 'multipv', 'nodes', 'time'):
            r[key] = int(t[t.index(key)+1]) if key in t else (1 if key == 'multipv' else None)
        return r if r['pv'] and r['depth'] is not None else None
    except (ValueError, IndexError):
        return None


def exact_cp(row):
    s = row['score'] if row else {}
    return s.get('value') if s.get('kind') == 'cp' and s.get('bound') is None else None


def summarize_events(events, multipv, bestmove):
    """Never assemble a comparison by mixing separate MultiPV output batches."""
    latest = {}
    batch = []
    snapshots = []
    for r in events:
        rank = r['multipv']
        if not 1 <= rank <= multipv:
            continue
        latest[rank] = r
        if rank == 1:
            batch = [r]
        elif batch and rank == len(batch) + 1:
            batch.append(r)
        else:
            batch = []
        if len(batch) == multipv:
            if len({v['depth'] for v in batch}) == 1 and len({v['pv'][0] for v in batch}) == multipv:
                snapshots.append(list(batch))
            batch = []
    complete = snapshots[-1] if snapshots else []
    latest_rows = [latest[i] for i in sorted(latest)]
    # Prefer an exact coherent snapshot aligned with final engine bestmove.
    exact = [b for b in snapshots if b[0]['pv'][0] == bestmove
             and all(exact_cp(r) is not None for r in b)]
    rows = exact[-1] if exact else complete
    if not rows:
        rows = latest_rows
    source = 'exact_snapshot' if exact else 'complete_snapshot' if complete else 'latest_per_rank'
    warnings = []
    if not complete:
        warnings.append('No complete MultiPV output batch; available candidates retained')
    if len(latest_rows) < multipv:
        warnings.append('Missing candidate ranks')
    if len({r['depth'] for r in latest_rows}) > 1:
        warnings.append('Latest candidates have mixed depths')
    if any(r['score']['bound'] for r in rows):
        warnings.append('Bounded scores are not exact evaluations')
    if rows and rows[0]['pv'][0] != bestmove:
        warnings.append('Selected snapshot differs from final bestmove')
    return {'rows': rows, 'latest_rows': latest_rows, 'row_source': source,
            'complete_depth': complete[0]['depth'] if complete else None,
            'comparison_depth': rows[0]['depth'] if exact else None,
            'comparison_ready': bool(exact), 'warnings': warnings}


class Engine:
    def __init__(self, config):
        self.config = config
        self.q = queue.Queue()
        self.log = []
        self.p = subprocess.Popen(config['command'], cwd=config.get('cwd'),
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, text=True, encoding='utf-8', errors='replace', bufsize=1)
        def pump():
            for line in self.p.stdout:
                self.q.put(line.rstrip())
            self.q.put(None)
        threading.Thread(target=pump, daemon=True).start()
    def send(self, command):
        if '\n' in command or '\r' in command:
            raise ValueError('USI command contains newline')
        self.log.append('> ' + command)
        self.p.stdin.write(command + '\n')
        self.p.stdin.flush()
    def until(self, prefix):
        deadline = time.monotonic() + self.config.get('timeout_seconds', 120)
        lines = []
        while True:
            try:
                line = self.q.get(timeout=max(0.001, deadline-time.monotonic()))
            except queue.Empty:
                raise TimeoutError('Engine timeout waiting for ' + prefix)
            if line is None:
                raise RuntimeError('Engine exited; last output: ' + repr(lines[-5:]))
            self.log.append('< ' + line)
            lines.append(line)
            if line.startswith(prefix):
                return lines
            if time.monotonic() > deadline:
                raise TimeoutError('Engine timeout waiting for ' + prefix)
    def close(self):
        if self.p.poll() is None:
            try:
                self.send('quit')
                self.p.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                self.p.kill()
                self.p.wait()
        self.p.stdin.close()
        self.p.stdout.close()
    def run(self, position, nodes, multipv, root_move=None):
        self.send('usi')
        hello = self.until('usiok')
        advertised = {}
        for line in hello:
            m = re.match(r'option name (.+?) type (\w+)', line)
            if m:
                advertised[m[1]] = m[2]
        if 'MultiPV' not in advertised:
            raise ValueError('Engine must support MultiPV')
        options = dict(self.config.get('options', {}))
        for name, value in [('Threads', 1), ('USI_Hash', 256), ('USI_OwnBook', 'false'),
                            ('BookFile', 'no_book'), ('PvInterval', 0), ('MultiPV', multipv)]:
            if name in advertised:
                options.setdefault(name, value)
        options['MultiPV'] = multipv
        for name, value in options.items():
            if name not in advertised:
                raise ValueError('Unsupported engine option: ' + name)
            self.send(f'setoption name {name} value {value}')
        self.send('isready')
        self.until('readyok')
        self.send('usinewgame')
        self.send(position)
        self.send(f'go nodes {nodes}' + (f' searchmoves {root_move}' if root_move else ''))
        lines = self.until('bestmove')
        events = [r for line in lines if (r := parse_info(line))]
        bestmove = lines[-1].split()[1]
        summary = summarize_events(events, multipv, bestmove)
        if 'PvInterval' not in advertised:
            summary['warnings'].append('PvInterval unavailable; output throttling cannot be disabled')
        return {'requested_nodes': nodes, 'requested_multipv': multipv,
                'bestmove': bestmove, 'events': events, **summary,
                'identity': [s for s in hello if s.startswith('id ')], 'effective_options': options}



def search(config, position, nodes, k, log_path, move=None):
    # Fresh process for every search: no transposition-table carry-over between budgets.
    e = Engine(config)
    try:
        result = e.run(position, nodes, k, move)
        if move and (result['bestmove'] != move or any(r['pv'][0] != move for r in result['rows'])):
            raise RuntimeError('Engine did not honor searchmoves')
        return result
    finally:
        e.close()
        log_path.write_text('\n'.join(e.log), encoding='utf-8')


def load_game(path):
    if path.suffix.lower() == '.json':
        game = json.loads(path.read_text(encoding='utf-8-sig'))
    else:
        game = None
        for enc in ('utf-8-sig', 'cp932'):
            try:
                content = path.read_text(encoding=enc)
            except UnicodeDecodeError:
                continue
            if '変化：' in content or '変化:' in content:
                raise ValueError('Variation KIF unsupported; export main line only')
            game = shogi.KIF.Parser.parse_str(content)[0]
            break
        if game is None:
            raise ValueError('Cannot decode KIF')
    board = shogi.Board(game.get('sfen') or shogi.STARTING_SFEN)
    if not game.get('moves'):
        raise ValueError('No moves found')
    for ply, usi in enumerate(game['moves'], 1):
        move = shogi.Move.from_usi(usi)
        if move not in board.legal_moves:
            raise ValueError(f'Illegal move at ply {ply}: {usi}')
        board.push(move)
    return game


def metrics(stages, played, played_result, gap_threshold):
    final = stages[-1]
    rows = final['rows']
    # Legacy test inputs without bestmove use their first PV.
    tops = [s.get('bestmove') or (s['rows'][0]['pv'][0] if s['rows'] else None) for s in stages]
    final_top = tops[-1]
    ready = final.get('comparison_ready', bool(rows))
    best = next((r for r in rows if r['pv'][0] == final_top), None)
    p = next((r for r in rows if r['pv'][0] == played), None)
    source = 'same_snapshot'
    if (p is None or exact_cp(p) is None) and played_result:
        p = next((r for r in played_result['rows'] if r['pv'][0] == played), None)
        source = 'separate_forced_search'
    bc, pc = exact_cp(best), exact_cp(p)
    delta = bc-pc if ready and bc is not None and pc is not None else None
    gap = bc-exact_cp(rows[1]) if ready and len(rows)>1 and bc is not None and exact_cp(rows[1]) is not None else None
    delta_status = ('ok_separate_search' if source == 'separate_forced_search' else 'ok_same_snapshot') if delta is not None else (
        'no_comparable_snapshot' if not ready else 'played_score_missing_or_bounded' if pc is None else 'best_score_missing_or_bounded')
    stable = None
    if final_top and all(t is not None for t in tops):
        stable = next(i for i in range(len(tops)) if all(t == final_top for t in tops[i:]))
    reasons = []
    if final_top == played and gap is not None and gap >= gap_threshold:
        reasons.append('best_move_with_large_gap')
    if final_top == played and stable is not None and stable > 0:
        reasons.append('best_move_emerges_at_larger_budget')
    if delta is not None and delta >= gap_threshold:
        reasons.append('possible_mistake')
    if best and best['score']['kind'] == 'mate':
        reasons.append('mate_related_position')
    return {'best_minus_played_cp': delta, 'top_two_gap_cp': gap,
            'top_moves_by_budget': tops,
            'comparison_status': delta_status, 'played_score_source': source,
            'top_two_gap_status': 'ok_same_snapshot' if gap is not None else 'unavailable',
            'final_bestmove': final_top, 'best_score': best['score'] if best else None,
            'played_score': p['score'] if p else None,
            'stable_from_tested_node_budget': stages[stable]['requested_nodes'] if stable is not None else None,
            'candidate_reasons': reasons,
            'human_selection_probability': None, 'human_discovery_difficulty': None,
            'necessary_reading_depth': None, 'practical_value': None,
            'warning': 'Search-budget proxy only; engine depth/PV length is not human necessary reading depth. Negative delta is retained as search inconsistency.'}


def analyze(game_path, config, out, max_plies=None):
    budgets = config.get('node_budgets', [10000, 100000, 1000000])
    if not budgets or any(type(n) is not int or n <= 0 for n in budgets) or budgets != sorted(set(budgets)):
        raise ValueError('node_budgets must be positive, strictly increasing integers')
    if config.get('multipv', 3) < 2:
        raise ValueError('multipv must be >= 2')
    game = load_game(game_path)
    out.mkdir(parents=True, exist_ok=False)
    (out/'logs').mkdir()
    board = shogi.Board(game.get('sfen') or shogi.STARTING_SFEN)
    initial = board.sfen()
    history, results = [], []
    report = {'version': '0.2.0', 'input_sha256': hashlib.sha256(game_path.read_bytes()).hexdigest(),
              'game': game, 'config': config, 'score_perspective': 'side_to_move_before_played_move',
              'search_reset': 'new process per budget and forced move', 'status': 'in_progress', 'positions': results}
    def save():
        tmp = out/'analysis.tmp'
        tmp.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(out/'analysis.json')
    save()
    try:
        for ply, move in enumerate(game['moves'], 1):
            if max_plies and ply > max_plies:
                break
            position = 'position sfen ' + initial + (' moves ' + ' '.join(history) if history else '')
            k = min(config.get('multipv', 3), len(list(board.legal_moves)))
            stages = [search(config, position, n, k, out/'logs'/f'{ply:03d}_{n}.log') for n in budgets]
            extra = None
            if not any(r['pv'][0] == move and exact_cp(r) is not None for r in stages[-1]['rows']):
                extra = search(config, position, budgets[-1], 1, out/'logs'/f'{ply:03d}_played.log', move)
            result = {'ply': ply, 'side': 'black' if board.turn == shogi.BLACK else 'white',
                      'sfen': board.sfen(), 'played': move, 'legal_moves': len(list(board.legal_moves)),
                      'stages': stages, 'forced_played_search': extra,
                      'metrics': metrics(stages, move, extra, config.get('gap_threshold_cp', 150))}
            results.append(result)
            board.push_usi(move)
            history.append(move)
            save()
            print(f'{ply}/{len(game["moves"])} {move}', flush=True)
        report['status'] = 'complete' if len(results) == len(game['moves']) else 'partial_requested'
    except Exception as exc:
        report['status'] = 'failed'
        report['error'] = str(exc)
        raise
    finally:
        save()
    with (out/'summary.csv').open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(['ply','side','played','best_minus_played_cp','top_two_gap_cp','stable_from_nodes','candidate_reasons','comparison_status','final_bestmove','row_source','candidate_depths','score_bounds','warnings'])
        for r in results:
            m = r['metrics']
            w.writerow([r['ply'],r['side'],r['played'],m['best_minus_played_cp'],m['top_two_gap_cp'],
                        m['stable_from_tested_node_budget'],';'.join(m['candidate_reasons']),
                        m['comparison_status'], m['final_bestmove'], r['stages'][-1]['row_source'],
                        ';'.join(str(x['depth']) for x in r['stages'][-1]['rows']),
                        ';'.join(x['score']['bound'] or 'none' for x in r['stages'][-1]['rows']),
                        ';'.join(r['stages'][-1]['warnings'])])
    return report


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('game', type=Path)
    p.add_argument('--config', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True, help='New output directory')
    p.add_argument('--max-plies', type=int)
    a = p.parse_args()
    if a.max_plies is not None and a.max_plies < 1:
        p.error('--max-plies must be positive')
    analyze(a.game, json.loads(a.config.read_text(encoding='utf-8-sig')), a.out, a.max_plies)
