# 一手分析 v0.2.0

## 今回の修正

- PvIntervalを公開しているエンジンでは、既定値を0にして途中のPV出力抑制を解除。非対応エンジンでは送信せず警告を保存。
- 最新の候補を順位別に `latest_rows` へ保存。深度が違っても破棄しない。
- 同じ出力のまとまりで順位1〜Nが順に出た、同一深度・異なる着手の候補だけを比較用スナップショットとする。過去の別出力同士を寄せ集めない。
- cp差の計算は、全候補が上下限なしのcpで、先頭が最終bestmoveと一致するスナップショットに限定。利用可能なもののうち最後のスナップショットを使う。
- 比較可能な過去スナップショットがあれば利用する。その深度は `comparison_depth`、最新の出力は `latest_rows` で区別する。
- 比較可能なスナップショットがなければ `rows` にも取得候補を残すが、cp差は計算しない。
- 実着手の値が未取得または上下限のみなら、searchmovesで追加探索。追加探索でも未確定なら未評価を維持。
- 予算別の最善手は、PVの欠損に左右されない `bestmove` を使用。
- CSVに比較状態、最終最善手、候補の深度、上下限、警告を追加。

## 使い方（Windows）

Python 3.10以降。ZIPを「すべて展開」し、analyze.pyのあるフォルダーでコマンドプロンプトを開く。

```shell
py -m pip install -r requirements.txt
py analyze.py game.kif --config config.laptop.json --out result_fixed_01 --max-plies 10
```

game.kifは手元の棋譜ファイル名に置き換える。空白を含む場合はダブルクォートで囲む。
config.laptop.jsonには、ユーザー確認済みの水匠5のフォルダーとAVX2実行ファイル名を設定済み。
探索量は1000/10000/100000、Threads=1、USI_Hash=256MB、MultiPV=3を維持。
既存の結果フォルダーは上書きしない。再実行時は新しい出力先名にする。
出力はanalysis.json、summary.csv（UTF-8 BOM）、logs。先に同じ10手で再確認する。

## CSVの意味

| 列 | 意味 |
|---|---|
| comparison_status | 評価差を計算できたか、その根拠／計算できない理由 |
| ok_same_snapshot | 同じ比較用候補群の、上下限なしcp同士の差 |
| ok_separate_search | 実着手を追加探索して差を計算。探索条件の配分が異なる |
| no_comparable_snapshot | 同一出力群・同一深度・全候補cp確定などの条件を満たさない |
| played_score_missing_or_bounded | 実着手のcpがない、または上下限のみ／詰み値 |
| best_score_missing_or_bounded | 最善候補のcpがない、または上下限のみ／詰み値 |
| row_source | exact_snapshot / complete_snapshot / latest_per_rank |
| candidate_depths | 選択したrowsの候補ごとの深度 |
| score_bounds | none＝上下限なし、lower＝下限、upper＝上限。mateはJSONで区別 |
| warnings | 深度不一致、候補不足、上下限などの注意点 |

「上下限なし」は、その探索で出力された値が境界値ではないという意味。真の局面価値や人間の勝率が確定したわけではない。
rowsは最新そのものとは限らない。最新の候補はlatest_rows、生の時系列はeventsに記録する。
比較基準は保守的なので、一部候補の値が確定していても全体の比較欄が空になる場合がある。

## 分析上の制限

- 評価値は各着手前の手番側基準。後手のプラスは後手有利。
- mateをcpに変換しない。上下限を確定値として差し引かない。
- 異なる深度の候補を同条件の評価差として扱わない。
- 追加探索は資源配分が違うため差は目安。負の差は不整合としてそのまま残す。
- stable_from_tested_node_budgetは測定した予算で最終bestmoveに一致し続けた最初の予算。人間の発見難度や必要読みの深さではない。
- 候補理由は調査対象の抽出用。名手認定の基準ではない。
- 人間選択率、必要読み深さ、実戦的価値は未評価。
- 全探索でエンジンを起動し直す。ハッシュ持ち越しはないがロード時間はかかる。
- 入力は本譜のみのKIF（UTF-8/CP932）またはUSI手順JSON。入力手数との照合が必要。

## 検証

18テスト：従来の通信・KIF・エラー処理に加えて、混在深度、別出力の混同、同一手重複、最終bestmoveとの不一致、過去の確定スナップショットの保存、欠損、上下限、PvInterval設定を確認。
提供された10手×3段階の記録済みeventsを再集計すると、候補行が全て空の探索は20/30から0/30へ改善。全候補cp確定で比較可能なのは4/30。これは過去データの再集計であり、新設定によるエンジンの再実行ではない。
修正版でのWindows実機再検証は未実施。元データは変更していない。ZIPにプロ棋譜やユーザーの解析結果は同梱しない。

```shell
py -m unittest discover -s tests -v
```

## 参考

- やねうら王のエンジンオプション（PvInterval）：https://github.com/yaneurao/YaneuraOu/wiki/思考エンジンオプション
- python-shogi：https://github.com/gunyarakun/python-shogi
- 水田氏ら（2024）の人間の間違えやすさの研究：https://ipsj.ixsq.nii.ac.jp/records/238513
本版は人間着手モデルを再現したものではない。
